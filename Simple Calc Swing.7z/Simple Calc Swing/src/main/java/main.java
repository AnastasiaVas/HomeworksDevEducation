public class main {
    public static void main(String args[]) {
    Calculator obj = new Calculator();
}
}
